package com.ejdm.gameboost;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Display;

/** Only changes Android system preferences after the user grants permission.
 * Does not hook into, access, edit, or inject PUBG game files or memory. */
public final class GameWatchService extends Service {
    public static final String START = "com.ejdm.gameboost.START";
    public static final String STOP = "com.ejdm.gameboost.STOP";
    private static final int NOTIFICATION_ID = 1081;
    private static final String MISSING = "__EJDM_NULL__";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String foreground = "";
    private boolean active = false;
    private boolean appliedBrightness = false, appliedDnd = false, appliedRefresh = false;
    private boolean reducedByHeat = false;
    private long lastEventTimestamp = 0L;
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!GameConfig.prefs(GameWatchService.this).getBoolean("watch", false)
                    || !GameConfig.usage(GameWatchService.this)) {
                stopSelf(); return;
            }
            scanForeground();
            if (GameConfig.isGame(foreground) && !active) activate();
            else if (!GameConfig.isGame(foreground) && active) deactivate();
            if (active) guardTemperature();
            handler.postDelayed(this, 2000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        // Recover original settings if Android terminated a previous monitor unexpectedly.
        if (GameConfig.prefs(this).getBoolean("playing", false)) deactivate();
        NotificationManager n = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && n != null) {
            NotificationChannel channel = new NotificationChannel(GameConfig.CHANNEL_ID,
                "Detección de juegos EJDM", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Activa temporalmente los ajustes elegidos al entrar a PUBG Mobile");
            n.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            GameConfig.prefs(this).edit().putBoolean("watch", false).apply();
            stopSelf(); return START_NOT_STICKY;
        }
        try {
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, GameConfig.CHANNEL_ID)
                : new Notification.Builder(this);
            Notification note = builder.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("EJDM GameBoost activado")
                .setContentText("Esperando PUBG Mobile · cambios reversibles")
                .setOngoing(true).build();
            if (Build.VERSION.SDK_INT >= 34)
                startForeground(NOTIFICATION_ID, note,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NOTIFICATION_ID, note);
            handler.removeCallbacks(poll);
            lastEventTimestamp = System.currentTimeMillis() - 300_000;
            foreground = "";
            poll.run();
        } catch (RuntimeException e) {
            stopSelf();
        }
        return START_STICKY;
    }

    private void scanForeground() {
        UsageStatsManager manager = (UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
        if (manager == null) return;
        long now = System.currentTimeMillis();
        try {
            UsageEvents e = manager.queryEvents(Math.max(0L, lastEventTimestamp), now);
            UsageEvents.Event event = new UsageEvents.Event();
            while (e.hasNextEvent()) {
                e.getNextEvent(event);
                int t = event.getEventType();
                if (t == UsageEvents.Event.MOVE_TO_FOREGROUND
                        || (Build.VERSION.SDK_INT >= 29 && t == UsageEvents.Event.ACTIVITY_RESUMED)) {
                    if (event.getPackageName() != null)
                        foreground = event.getPackageName();
                }
            }
        } catch (RuntimeException ignored) { }
        // 1 ms overlap keeps events that fall exactly at a polling boundary.
        lastEventTimestamp = Math.max(0, now - 1);
    }

    private void activate() {
        active = true;
        SharedPreferences p = GameConfig.prefs(this);
        p.edit().putBoolean("playing", true).apply();
        final String profile = GameConfig.profile(this);
        if (p.getBoolean("bright", false) && GameConfig.write(this)) {
            try {
                String orig = Settings.System.getString(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
                String mode = Settings.System.getString(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE);
                p.edit().putString("orig_bright", orig == null ? MISSING : orig)
                    .putString("orig_mode", mode == null ? MISSING : mode).apply();
                boolean modeOk = Settings.System.putInt(getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                boolean valueOk = Settings.System.putInt(getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, GameConfig.selectedBrightness(this));
                appliedBrightness = modeOk && valueOk;
                if (!appliedBrightness) restoreValue(Settings.System.SCREEN_BRIGHTNESS_MODE,"orig_mode");
                p.edit().putBoolean("applied_brightness", appliedBrightness).apply();
            } catch (RuntimeException ignored) { appliedBrightness = false; }
        }
        if (p.getBoolean("hz", false) && GameConfig.write(this)) {
            try {
                DisplayManager mgr = (DisplayManager)getSystemService(DISPLAY_SERVICE);
                Display display = mgr == null ? null : mgr.getDisplay(Display.DEFAULT_DISPLAY);
                float max = 0f;
                if (display != null) for (Display.Mode mode : display.getSupportedModes()) {
                    max = Math.max(max, mode.getRefreshRate());
                }
                if (max >= 60f) {
                    String orig = Settings.System.getString(getContentResolver(), "peak_refresh_rate");
                    p.edit().putString("orig_hz", orig == null ? MISSING : orig).apply();
                    appliedRefresh = Settings.System.putFloat(getContentResolver(), "peak_refresh_rate", max);
                    p.edit().putBoolean("applied_hz", appliedRefresh).apply();
                }
            } catch (RuntimeException ignored) { appliedRefresh = false; }
        }
        if (p.getBoolean("silence", false) && GameConfig.dnd(this)) {
            try {
                NotificationManager n = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                if (n != null) {
                    p.edit().putInt("orig_filter", n.getCurrentInterruptionFilter()).apply();
                    n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                    appliedDnd = true;
                    p.edit().putBoolean("applied_dnd", true).apply();
                }
            } catch (RuntimeException ignored) { appliedDnd = false; }
        }
    }

    /** Ajusta SOLO brillo y SOLO con el consentimiento dado por el usuario.
     * NO baja calidad gráfica, no altera PUBG y no garantiza aumentar FPS. */
    private void guardTemperature() {
        SharedPreferences p = GameConfig.prefs(this);
        if (!appliedBrightness || !p.getBoolean("thermal_guard", true) || !GameConfig.write(this)) return;
        boolean hot = DeviceInfo.overheating(this);
        if (hot == reducedByHeat) return;
        int target = hot ? Math.min(GameConfig.selectedBrightness(this), 120)
                         : GameConfig.selectedBrightness(this);
        try {
            if (Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, target))
                reducedByHeat = hot;
        } catch (RuntimeException ignored) { }
    }

    private void restoreValue(String key, String preferenceKey) {
        SharedPreferences p = GameConfig.prefs(this);
        String value = p.getString(preferenceKey, MISSING);
        try {
            if (MISSING.equals(value)) Settings.System.putString(getContentResolver(), key, null);
            else Settings.System.putString(getContentResolver(), key, value);
        } catch (RuntimeException ignored) { }
    }

    private void deactivate() {
        SharedPreferences p = GameConfig.prefs(this);
        boolean touchedBrightness = appliedBrightness || p.getBoolean("applied_brightness", false);
        boolean touchedHz = appliedRefresh || p.getBoolean("applied_hz", false);
        boolean touchedDnd = appliedDnd || p.getBoolean("applied_dnd", false);
        if (touchedBrightness && GameConfig.write(this)) {
            restoreValue(Settings.System.SCREEN_BRIGHTNESS, "orig_bright");
            restoreValue(Settings.System.SCREEN_BRIGHTNESS_MODE, "orig_mode");
        }
        if (touchedHz && GameConfig.write(this)) restoreValue("peak_refresh_rate", "orig_hz");
        if (touchedDnd && GameConfig.dnd(this)) {
            try {
                NotificationManager n = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                if (n != null) n.setInterruptionFilter(p.getInt("orig_filter", NotificationManager.INTERRUPTION_FILTER_ALL));
            } catch (RuntimeException ignored) { }
        }
        p.edit().putBoolean("playing", false).putBoolean("applied_brightness", false)
             .putBoolean("applied_hz", false).putBoolean("applied_dnd", false).apply();
        appliedBrightness = false; appliedRefresh = false; appliedDnd = false; reducedByHeat = false; active = false;
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(poll);
        deactivate();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
