package com.ejdm.gameboost;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Process;
import android.provider.Settings;

final class GameConfig {
    static final String PREFS = "gameboost_prefs";
    static final String[] GAME_PACKAGES = {
        "com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.pubg.imobile"
    };
    static final String CHANNEL_ID = "ejdm_gamewatch";
    static final String PROFILE_VISUAL = "VISUAL";
    static final String PROFILE_CUSTOM = "PERSONALIZADO";
    static final String PROFILE_FLUIDEZ = "FLUIDEZ";
    static final String PROFILE_BALANCE = "EQUILIBRADO";
    private GameConfig() { }
    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    static boolean isGame(String p) {
        for (String s : GAME_PACKAGES) if (s.equals(p)) return true;
        return false;
    }
    static boolean usage(Context c) {
        AppOpsManager a = (AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);
        if (a == null) return false;
        try {
            return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), c.getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (RuntimeException e) { return false; }
    }
    static boolean write(Context c) { return Settings.System.canWrite(c); }
    static boolean dnd(Context c) {
        NotificationManager m = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        return m != null && m.isNotificationPolicyAccessGranted();
    }
    static String profile(Context c) {
        return prefs(c).getString("profile", PROFILE_BALANCE);
    }
    static int brightness(String p) {
        if (PROFILE_VISUAL.equals(p)) return 224;
        if (PROFILE_FLUIDEZ.equals(p)) return 176;
        return 192;
    }
    static int selectedBrightness(Context c) {
        if (PROFILE_CUSTOM.equals(profile(c)))
            return Math.max(80, Math.min(255, prefs(c).getInt("custom_bright", 198)));
        return brightness(profile(c));
    }
    static int targetFPS(Context c) {
        return prefs(c).getInt("fps_target", 60);
    }
    static String desiredQuality(Context c) {
        return prefs(c).getString("custom_quality", "HDR");
    }
    static String suggestedSettings(Context c) {
        String p = profile(c);
        if (PROFILE_CUSTOM.equals(p))
            return "Perfil personalizado: calidad objetivo " + desiredQuality(c)
                + " y FPS objetivo " + targetFPS(c)
                + ". SON REFERENCIAS para configurar PUBG manualmente, no valores forzados. "
                + "Si el juego marca 'Próximamente', la opción continúa bloqueada.";
        return suggestedSettings(p);
    }
    static String suggestedSettings(String p) {
        if (PROFILE_VISUAL.equals(p))
            return "En PUBG: aumenta la calidad de gráficos y la tasa de cuadros hasta lo que permita el juego. Si hay calentamiento, reduce un nivel los gráficos.";
        if (PROFILE_FLUIDEZ.equals(p))
            return "En PUBG: utiliza gráficos Suaves y la mayor tasa de cuadros disponible. Prioriza FPS estables sobre efectos visuales.";
        return "En PUBG: prueba gráficos Equilibrados o HD con FPS altos, y reduce calidad si hay caídas de rendimiento.";
    }
}
