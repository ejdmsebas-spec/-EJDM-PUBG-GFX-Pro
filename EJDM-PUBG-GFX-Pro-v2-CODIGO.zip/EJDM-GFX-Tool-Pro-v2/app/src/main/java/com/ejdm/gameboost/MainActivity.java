package com.ejdm.gameboost;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** One-screen gaming dashboard. No root, no overlays, no game-file changes. */
public final class MainActivity extends Activity {
    private static final int BG = 0xFF080D1A;
    private static final int CARD = 0xFF141C30;
    private static final int WHITE = 0xFFF3F5FF;
    private static final int MUTED = 0xFF9FAFCE;
    private static final int ACCENT = 0xFF7C67FF;
    private static final int CYAN = 0xFF44DDF1;
    private static final int GREEN = 0xFF52E4AA;
    private SharedPreferences pref;
    private ScrollView scroller;
    private LinearLayout content;
    private boolean rendered;
    private final int SPACE = 16;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        pref = GameConfig.prefs(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.POST_NOTIFICATIONS }, 90);
        }
        render(0);
    }

    @Override protected void onResume() {
        super.onResume();
        if (rendered) render(0);
    }

    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density * v + .5f); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams margins(int top, int bottom) {
        LinearLayout.LayoutParams v = lp(-1, -2);
        v.setMargins(0, dp(top), 0, dp(bottom)); return v;
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable gradient() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{ 0xFF3F2AAB, 0xFF26236C, 0xFF172247 });
        d.setCornerRadius(dp(24)); return d;
    }
    private TextView text(String str, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(str); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void addText(LinearLayout to, String s, int size, int color, boolean bold, int top) {
        to.addView(text(s, size, color, bold), margins(top, 0));
    }
    private LinearLayout panel() {
        LinearLayout l = vertical();
        l.setPadding(dp(18), dp(18), dp(18), dp(18));
        l.setBackground(shape(CARD, 20)); return l;
    }
    private void title(String s, String sub) {
        addText(content, s, 17, WHITE, true, 24);
        if (sub != null) addText(content, sub, 12, MUTED, false, 5);
    }

    private void render(int targetY) {
        rendered = true;
        scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            scroller.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }
        content = vertical();
        content.setPadding(dp(SPACE), dp(20), dp(SPACE), dp(30));
        scroller.addView(content);
        setContentView(scroller);
        TextView logo = text("◈  EJDM  /  PUBG GFX PRO", 15, CYAN, true);
        content.addView(logo, margins(4, 17));
        LinearLayout hero = vertical();
        hero.setPadding(dp(21), dp(22), dp(21), dp(22));
        hero.setBackground(gradient());
        addText(hero, "PUBG MOBILE  •  VERSIÓN 2.0", 12, 0xFFBECEFF, true, 0);
        addText(hero, "CALIDAD + FLUIDEZ", 25, WHITE, true, 8);
        addText(hero, "Centro avanzado de optimización de Android. Activa tus preferencias al iniciar PUBG y restáuralas al salir. No altera el juego.", 13, 0xFFE2E5FF, false, 11);
        content.addView(hero, margins(0, 0));

        title("01   ELIGE TU PERFIL", "Elige un equilibrio entre imagen, comodidad y estabilidad");
        profileCard("VISUAL", "◉  MODO VISUAL", "Brillo más alto · preferencia de frecuencia de pantalla", ACCENT);
        profileCard("FLUIDEZ", "⚡  MODO FLUIDEZ", "Prioriza tasa de cuadros en los ajustes recomendados", CYAN);
        profileCard("EQUILIBRADO", "◎  EQUILIBRADO", "Combina comodidad visual y consumo razonable", GREEN);
        profileCard("PERSONALIZADO", "◈  AJUSTES PERSONALIZADOS", "Tu brillo y tus objetivos visuales, sin modificar PUBG", 0xFFFFC66D);
        if ("PERSONALIZADO".equals(GameConfig.profile(this))) customPanel();

        title("02   ACTIVACIÓN AUTOMÁTICA", "Permisos controlados por ti · sin root");
        LinearLayout controls = panel();
        toggle(controls, "watch", "Detectar PUBG automáticamente",
                "Mantiene una notificación de vigilancia mientras esté activado.", false);
        divider(controls);
        toggle(controls, "hz", "Preferir Hz altos de pantalla",
                "Prueba a solicitar el modo de refresco más alto disponible. No aumenta el FPS interno del juego.", false);
        divider(controls);
        toggle(controls, "bright", "Brillo según perfil",
                "Modifica temporalmente el brillo del sistema y lo restaura al salir.", false);
        divider(controls);
        toggle(controls, "silence", "Reducir interrupciones",
                "Activa No molestar en modo prioritario y recupera la configuración previa.", false);
        divider(controls);
        toggle(controls, "thermal_guard", "Protección visual por temperatura",
                "Si Android informa sobrecalentamiento, reduce temporalmente el brillo configurado. Requiere activar control de brillo.", true);
        content.addView(controls, margins(12, 0));

        title("03   DIAGNÓSTICO REAL", "Datos del sistema, no FPS ni calidad renderizada de PUBG");
        LinearLayout diagnostics = panel();
        addText(diagnostics, DeviceInfo.inspect(this), 13, WHITE, false, 0);
        content.addView(diagnostics, margins(12,0));
        button("↻   ACTUALIZAR DIAGNÓSTICO", false, () -> render(scroller.getScrollY()));

        title("04   PERMISOS", "Solo activa los que necesites");
        LinearLayout permissions = panel();
        permissionRow(permissions, "Acceso al uso de aplicaciones", GameConfig.usage(this),
                "Detecta cuándo PUBG está en pantalla", () -> openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS, false));
        divider(permissions);
        permissionRow(permissions, "Modificar ajustes del sistema", GameConfig.write(this),
                "Necesario para brillo y preferencia de Hz", () -> openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, true));
        divider(permissions);
        permissionRow(permissions, "Acceso a No molestar", GameConfig.dnd(this),
                "Solo para reducir interrupciones", () -> openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, false));
        content.addView(permissions, margins(12, 0));

        title("05   INICIA TU PARTIDA", "Puedes abrir PUBG desde aquí o desde su icono habitual");
        button("▶   INICIAR PUBG MOBILE", true, () -> launchGame());
        button(pref.getBoolean("watch", false) ? "■   DESACTIVAR VIGILANCIA" : "◎   ACTIVAR VIGILANCIA",
               false, () -> switchWatch());

        title("RECOMENDACIÓN DE GRÁFICOS", null);
        LinearLayout help = panel();
        addText(help, GameConfig.suggestedSettings(this), 13, WHITE, false, 0);
        addText(help, "ULTRA HDR: si aparece ‘Próximamente’ en PUBG, la aplicación no puede desbloquearlo. Tampoco modifica texturas, shaders, resolución interna, FPS, archivos ni memoria del juego. 90 Hz de pantalla no implican 90 FPS.", 12, MUTED, false, 12);
        content.addView(help, margins(12, 0));
        addText(content, "EJDM PUBG GFX Pro • Beta 2.0 • Android 8.0+ • Sin root • Sin anuncios • Local", 11, 0xFF7A89AE, false, 23);
        scroller.post(() -> scroller.scrollTo(0, targetY));
    }

    private void profileCard(String code, String label, String description, int color) {
        boolean chosen = code.equals(GameConfig.profile(this));
        LinearLayout box = vertical();
        box.setPadding(dp(17), dp(15), dp(17), dp(15));
        GradientDrawable background = shape(chosen ? 0xFF252B4F : CARD, 17);
        if (chosen) background.setStroke(dp(2), color);
        box.setBackground(background);
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 15, chosen ? color : WHITE, true);
        r.addView(name, new LinearLayout.LayoutParams(0,-2,1));
        TextView selected = text(chosen ? "ACTIVO" : "ELEGIR", 10, chosen ? GREEN : MUTED, true);
        r.addView(selected);
        box.addView(r);
        addText(box, description, 12, MUTED, false, 6);
        box.setOnClickListener(v -> { pref.edit().putString("profile", code).apply(); render(scroller.getScrollY()); });
        content.addView(box, margins(10, 0));
    }

    private void customPanel() {
        LinearLayout p = panel();
        addText(p, "BRILLO TEMPORAL", 13, CYAN, true, 0);
        TextView brightnessLabel = text("Valor: " + GameConfig.selectedBrightness(this) + " / 255", 12, WHITE, false);
        p.addView(brightnessLabel, margins(8,0));
        SeekBar brightness = new SeekBar(this);
        brightness.setMax(175);
        brightness.setProgress(pref.getInt("custom_bright",198) - 80);
        brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int value, boolean fromUser) {
                brightnessLabel.setText("Valor: " + (80 + value) + " / 255");
                if (fromUser) pref.edit().putInt("custom_bright", 80 + value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        p.addView(brightness);
        addText(p, "OBJETIVO FPS (RECOMENDACIÓN)", 13, CYAN, true, 14);
        int[] fps = {30,40,60,90,120};
        int index = 2;
        for (int i=0; i<fps.length; i++) if (fps[i] == GameConfig.targetFPS(this)) index = i;
        TextView fpsText = text("Referencia para PUBG: " + fps[index] + " FPS", 12, WHITE, false);
        p.addView(fpsText, margins(8,0));
        SeekBar fpsControl = new SeekBar(this);
        fpsControl.setMax(4); fpsControl.setProgress(index);
        fpsControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int value, boolean fromUser) {
                fpsText.setText("Referencia para PUBG: " + fps[value] + " FPS");
                if (fromUser) pref.edit().putInt("fps_target", fps[value]).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        p.addView(fpsControl);
        addText(p, "El control anterior NO cambia los FPS de PUBG: solo guarda tu objetivo.", 11, MUTED, false, 2);
        addText(p, "CALIDAD OBJETIVO", 13, CYAN, true, 15);
        TextView choose = text("Elegida: " + GameConfig.desiredQuality(this) + "  ›",14,WHITE,true);
        choose.setBackground(shape(0xFF283353, 12));
        choose.setPadding(dp(15),dp(13),dp(15),dp(13));
        choose.setOnClickListener(v -> {
            final String[] options = {"Suave", "Equilibrado", "HD", "HDR", "Ultra HDR"};
            new android.app.AlertDialog.Builder(this)
                .setTitle("Calidad que deseas dentro de PUBG")
                .setItems(options, (dialog, index2) -> {
                    pref.edit().putString("custom_quality", options[index2]).apply();
                    render(scroller.getScrollY());
                })
                .setNegativeButton("Cancelar", null).show();
        });
        p.addView(choose, margins(7,0));
        addText(p, "Seleccionar Ultra HDR aquí no lo habilita en PUBG si el juego lo bloquea.", 11, MUTED, false, 10);
        content.addView(p, margins(12,0));
    }

    private void divider(LinearLayout p) {
        View v = new View(this);
        v.setBackgroundColor(0xFF293149);
        p.addView(v, margins(12, 12));
        ViewGroup.LayoutParams params = v.getLayoutParams();
        params.height = dp(1); v.setLayoutParams(params);
    }
    private void toggle(LinearLayout p, String key, String label, String desc, boolean fallback) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout labels = vertical();
        addText(labels, label, 14, WHITE, true, 0);
        addText(labels, desc, 12, MUTED, false, 4);
        r.addView(labels, new LinearLayout.LayoutParams(0,-2,1));
        Switch s = new Switch(this);
        s.setContentDescription(label);
        s.setChecked(pref.getBoolean(key, fallback));
        s.setOnCheckedChangeListener((v, checked) -> {
            if ("watch".equals(key)) {
                if (checked && !GameConfig.usage(this)) {
                    s.setChecked(false);
                    Toast.makeText(this,"Primero concede acceso al uso de aplicaciones",Toast.LENGTH_LONG).show();
                    openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS, false);
                    return;
                }
                pref.edit().putBoolean(key, checked).apply();
                updateService(checked);
                render(scroller.getScrollY());
            } else {
                pref.edit().putBoolean(key, checked).apply();
                if (checked && (("bright".equals(key) || "hz".equals(key)) && !GameConfig.write(this)))
                    Toast.makeText(this,"Activa el permiso de modificar ajustes más abajo",Toast.LENGTH_LONG).show();
                if (checked && "silence".equals(key) && !GameConfig.dnd(this))
                    Toast.makeText(this,"Activa el permiso No molestar más abajo",Toast.LENGTH_LONG).show();
            }
        });
        LinearLayout.LayoutParams toggleParams = lp(-2,-2);
        toggleParams.setMargins(dp(12),0,0,0);
        r.addView(s,toggleParams);
        p.addView(r);
    }
    private void permissionRow(LinearLayout p, String name, boolean granted, String desc, Runnable click) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout l = vertical();
        addText(l, name, 14, WHITE, true, 0);
        addText(l, desc, 11, MUTED, false, 4);
        r.addView(l, new LinearLayout.LayoutParams(0,-2,1));
        TextView status = text(granted ? "✓ OK" : "ABRIR  ›", 11, granted ? GREEN : CYAN,true);
        status.setPadding(dp(9),dp(8),0,dp(8));
        r.addView(status);
        r.setOnClickListener(v -> click.run());
        p.addView(r);
    }
    private void button(String label, boolean primary, Runnable onclick) {
        TextView b = text(label, 15, primary ? BG : WHITE,true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(54));
        b.setBackground(shape(primary ? CYAN : 0xFF293654, 15));
        b.setOnClickListener(v -> onclick.run());
        content.addView(b,margins(10,0));
    }
    private void openSettings(String action, boolean packageUri) {
        try {
            Intent i = new Intent(action);
            if (packageUri) i.setData(Uri.parse("package:"+getPackageName()));
            startActivity(i);
        } catch (RuntimeException e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }
    private void switchWatch() {
        boolean to = !pref.getBoolean("watch",false);
        if (to && !GameConfig.usage(this)) {
            Toast.makeText(this,"Concede acceso al uso de apps primero",Toast.LENGTH_LONG).show();
            openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS,false); return;
        }
        pref.edit().putBoolean("watch",to).apply();
        updateService(to);
        render(scroller.getScrollY());
    }
    private void updateService(boolean enable) {
        try {
            Intent svc = new Intent(this, GameWatchService.class);
            svc.setAction(enable ? GameWatchService.START : GameWatchService.STOP);
            if (enable) {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
                else startService(svc);
            } else stopService(svc);
        } catch (RuntimeException e) {
            Toast.makeText(this,"El sistema bloqueó la vigilancia en segundo plano",Toast.LENGTH_LONG).show();
            pref.edit().putBoolean("watch", false).apply();
        }
    }
    private void launchGame() {
        if (pref.getBoolean("watch",false)) updateService(true);
        PackageManager pm = getPackageManager();
        for (String id:GameConfig.GAME_PACKAGES) {
            try {
                Intent game = pm.getLaunchIntentForPackage(id);
                if (game != null) { startActivity(game); return; }
            } catch (RuntimeException ignored) { }
        }
        new android.app.AlertDialog.Builder(this)
            .setTitle("PUBG Mobile no detectado")
            .setMessage("Instala la versión oficial de PUBG Mobile. La app no descarga ni modifica el juego.")
            .setPositiveButton("Abrir Google Play", (d,w) -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.tencent.ig"))); }
                catch (RuntimeException ex) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.tencent.ig"))); }
            })
            .setNegativeButton("Cerrar", null).show();
    }
}
