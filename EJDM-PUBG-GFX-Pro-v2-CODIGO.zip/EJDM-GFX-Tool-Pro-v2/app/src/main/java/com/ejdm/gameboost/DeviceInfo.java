package com.ejdm.gameboost;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.view.Display;

import java.util.Locale;

/** Datos de sistema, NO FPS de PUBG ni consumo individual de la GPU. */
final class DeviceInfo {
    private DeviceInfo() { }

    static float batteryTempC(Context context) {
        Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) return -1f;
        int temperature = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        return temperature < 0 ? -1f : temperature / 10f;
    }

    static int batteryPct(Context context) {
        Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) return -1;
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return level < 0 || scale <= 0 ? -1 : Math.round(100f * level / scale);
    }

    static int thermalStatus(Context context) {
        if (Build.VERSION.SDK_INT < 29) return -1;
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        return pm == null ? -1 : pm.getCurrentThermalStatus();
    }

    static String thermalText(Context context) {
        int s = thermalStatus(context);
        if (s < 0) return "No disponible";
        String[] labels = {"Sin calor", "Ligero", "Moderado", "Elevado", "Crítico", "Emergencia", "Apagado inminente"};
        return s < labels.length ? labels[s] : "Estado " + s;
    }

    static boolean overheating(Context context) {
        // Los indicadores reportados por Android varían según fabricante.
        return thermalStatus(context) >= 3 || batteryTempC(context) >= 43.0f;
    }

    static String inspect(Context context) {
        DisplayManager manager = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
        Display display = manager == null ? null : manager.getDisplay(Display.DEFAULT_DISPLAY);
        float maxHz = 0f, actualHz = 0f;
        String resolution = "Sin dato";
        if (display != null) {
            actualHz = display.getRefreshRate();
            android.graphics.Point size = new android.graphics.Point();
            display.getRealSize(size);
            resolution = size.x + " × " + size.y;
            for (Display.Mode m : display.getSupportedModes())
                maxHz = Math.max(maxHz, m.getRefreshRate());
        }
        ActivityManager activity = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        String ram = "Sin dato";
        if (activity != null) {
            ActivityManager.MemoryInfo mem = new ActivityManager.MemoryInfo();
            activity.getMemoryInfo(mem);
            ram = String.format(Locale.US, "%.1f GB disponibles / %.1f GB totales",
                    mem.availMem / 1073741824.0, mem.totalMem / 1073741824.0);
        }
        float temp = batteryTempC(context);
        return "Pantalla: " + resolution + "\n"
            + "Frecuencia actual: " + Math.round(actualHz) + " Hz · máxima detectada: " + Math.round(maxHz) + " Hz\n"
            + "Batería: " + (batteryPct(context) < 0 ? "sin dato" : batteryPct(context) + "%")
            + (temp < 0 ? "" : String.format(Locale.US, " · %.1f °C", temp)) + "\n"
            + "Estado térmico: " + thermalText(context) + "\n"
            + "Memoria: " + ram + "\n"
            + "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
    }
}
